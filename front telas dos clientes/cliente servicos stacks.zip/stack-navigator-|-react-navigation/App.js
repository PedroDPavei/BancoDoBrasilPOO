import * as React from 'react';
import { Button, View, Text, TextInput, SafeAreaView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
const Stack = createStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Main />
    </NavigationContainer>
  );
}

function Atendimento({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    <Stack.Navigator>
      <Stack.Screen name="Atendimento agora" component={AtAgora} />
      <Stack.Screen name="Marcar horário" component={AtHorario} />
    </Stack.Navigator>
    </View>
  );
}

function Transacoes({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    <Stack.Navigator>
      <Stack.Screen name="Sacar" component={Sacar} />
      <Stack.Screen name="Depositar" component={Depositar} />
    </Stack.Navigator>
    </View>
  );
  function Sacar ({ navigation }) {
    <View>
      <Text>Quanto voce deseja sacar?</Text>
      <Text>Saldo atual: R$ xxx,xx</Text>
      <TextInput placeholder="Insira o valor"></TextInput>
      <Button title="Confirmar"></Button>
    </View>
}
  function Depositar ({ navigation }) {
    <View>
      <Text>Quanto voce deseja depositar?</Text>
      <Text>Saldo atual: R$ xxx,xx</Text>
      <TextInput placeholder="Insira o valor"></TextInput>
      <Button title="Confirmar"></Button>
    </View>
}

function Servicos({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    <Stack.Navigator>
      <Stack.Screen name="Empréstimo" component={Emprestimo} />
      <Stack.Screen name="Financiamento" component={Financiamento} />
      <Stack.Screen name="Seguro" component={Seguro} />
    </Stack.Navigator>
    </View>
  );
}




function Main() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Atendimento" component={Atendimento} />
      <Stack.Screen name="Transações" component={Transacoes} />
      <Stack.Screen name="Serviços" component={Servicos} />
    </Stack.Navigator>
  );
}