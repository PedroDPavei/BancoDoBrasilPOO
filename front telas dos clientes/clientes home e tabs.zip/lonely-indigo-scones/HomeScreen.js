import { Text, SafeAreaView, StyleSheet, Image } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
export default function App() {
  return (
<Text></Text>
  );
}